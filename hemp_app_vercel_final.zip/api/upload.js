import formidable from 'formidable';
import fs from 'fs';
import PDFParser from 'pdf2json';

export const config = {
  api: {
    bodyParser: false,
  },
};

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const form = formidable({ multiples: false });
  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Upload failed' });
    }

    const pdfPath = files.pdf[0].filepath;
    try {
      const rawText = await extractPDFText(pdfPath);
      const cleaned = cleanLayout(rawText);
      // Simple JSON structure without GPT for demo
      const jsonData = { content: cleaned };
      return res.status(200).json(jsonData);
    } catch (error) {
      console.error(error);
      return res.status(500).json({ error: 'Parsing failed' });
    }
  });
}

function extractPDFText(pdfFile) {
  return new Promise((resolve, reject) => {
    const pdfParser = new PDFParser();
    pdfParser.on("pdfParser_dataError", err => reject(err.parserError));
    pdfParser.on("pdfParser_dataReady", pdfData => {
      const pages = pdfData.Pages.map(p => p.Texts.map(t => decodeURIComponent(t.R[0].T)).join(' '));
      resolve(pages.join('\n\n---PAGEBREAK---\n\n'));
    });
    pdfParser.loadPDF(pdfFile);
  });
}

function cleanLayout(rawText) {
  return rawText
    .replace(/---PAGEBREAK---/g, '\n')
    .replace(/\n\s*\d+\s*\n/g, '\n')
    .replace(/\s{2,}/g, ' ')
    .trim();
}