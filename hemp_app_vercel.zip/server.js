import express from 'express';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
import { parsePDFAndClean } from './pdfParser.js';
import cors from 'cors';

const app = express();
app.use(cors());

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.static(path.join(__dirname, 'public')));

const upload = multer({ dest: '/tmp' });

app.post('/api/upload', upload.single('pdf'), async (req, res) => {
  try {
    const pdfPath = req.file.path;
    const jsonData = await parsePDFAndClean(pdfPath);
    res.json(jsonData);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Parsing failed' });
  }
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ Hemp App running on port ${PORT}`));
