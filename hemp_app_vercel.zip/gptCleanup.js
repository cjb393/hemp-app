import OpenAI from 'openai';
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function gptCleanup(cleanedText) {
  const systemPrompt = `You are a legal document parser. Preserve all numbering and section hierarchy. Output ONLY valid JSON array of sections.`;

  const completion = await openai.chat.completions.create({
    model: 'gpt-4o',
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: cleanedText }
    ],
    temperature: 0
  });

  return completion.choices[0].message.content;
}