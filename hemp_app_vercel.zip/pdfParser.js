import fs from 'fs';
import PDFParser from 'pdf2json';
import { gptCleanup } from './gptCleanup.js';

export async function parsePDFAndClean(pdfPath) {
  const rawText = await extractPDFText(pdfPath);
  const cleaned = cleanLayout(rawText);
  const jsonStructured = await gptCleanup(cleaned);
  return JSON.parse(jsonStructured);
}

function extractPDFText(pdfFile) {
  return new Promise((resolve, reject) => {
    const pdfParser = new PDFParser();
    pdfParser.on("pdfParser_dataError", err => reject(err.parserError));
    pdfParser.on("pdfParser_dataReady", pdfData => {
      const pages = pdfData.Pages.map(p => p.Texts.map(t => decodeURIComponent(t.R[0].T)).join(' '));
      resolve(pages.join('\n\n---PAGEBREAK---\n\n'));
    });
    pdfParser.loadPDF(pdfFile);
  });
}

function cleanLayout(rawText) {
  return rawText
    .replace(/---PAGEBREAK---/g, '\n')
    .replace(/\n\s*\d+\s*\n/g, '\n')
    .replace(/\s{2,}/g, ' ')
    .trim();
}